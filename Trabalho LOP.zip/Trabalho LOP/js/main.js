
const cena = new THREE.Scene();
cena.background = new THREE.Color(0x87ceeb);

const cam = new THREE.PerspectiveCamera(
  75,
  window.innerWidth / window.innerHeight,
  0.1,
  1000
);

const render = new THREE.WebGLRenderer({ antialias: true });
render.setSize(window.innerWidth, window.innerHeight);
document.body.appendChild(render.domElement);
 
const luzDir = new THREE.DirectionalLight(0xffffff, 1);
luzDir.position.set(10, 10, 5);
cena.add(luzDir);

cena.add(new THREE.AmbientLight(0xffffff, 0.4));


const piso = new THREE.Mesh(
  new THREE.PlaneGeometry(200, 200),
  new THREE.MeshPhongMaterial({ color: 0x228b22 })
);
piso.rotation.x = -Math.PI / 2;
cena.add(piso);

const carro = new THREE.Group();
const baseCarro = new THREE.Mesh(
  new THREE.BoxGeometry(2, 1, 4),
  new THREE.MeshPhongMaterial({ color: 0xff0000 })
);
baseCarro.position.y = 0.75;
carro.add(baseCarro);

const geoRoda = new THREE.CylinderGeometry(0.5, 0.5, 0.5, 32);
const matRoda = new THREE.MeshPhongMaterial({ color: 0x000000 });

function roda(px, pz) {
  const r = new THREE.Mesh(geoRoda, matRoda);
  r.rotation.z = Math.PI / 2;
  r.position.set(px, 0.25, pz);
  return r;
}
carro.add(roda(1, 1.5));
carro.add(roda(-1, 1.5));
carro.add(roda(1, -1.5));
carro.add(roda(-1, -1.5));

cena.add(carro);
const teclas = {};

window.addEventListener("keydown", e => {
  teclas[e.key.toLowerCase()] = true;
});

window.addEventListener("keyup", e => {
  teclas[e.key.toLowerCase()] = false;
});

cam.position.set(0, 5, 10);

function loop() {
  requestAnimationFrame(loop);

  let vel = 0.15;
  let giro = 0.03;

  if (teclas["a"]) carro.rotation.y += giro;
  else if (teclas["d"]) carro.rotation.y -= giro;

  let dir = new THREE.Vector3();
  carro.getWorldDirection(dir);

  if (teclas["s"]) {
    carro.position.add(dir.clone().multiplyScalar(vel));
  } else if (teclas["w"]) {
    carro.position.add(dir.clone().multiplyScalar(-vel));
  }

  
  let desloc = new THREE.Vector3(0, 4, 8);
  let posCam = desloc.clone().applyMatrix4(carro.matrixWorld);

  cam.position.copy(posCam);
  cam.lookAt(carro.position);

  render.render(cena, cam);
}

loop();


window.addEventListener("resize", () => {
  cam.aspect = window.innerWidth / window.innerHeight;
  cam.updateProjectionMatrix();
  render.setSize(window.innerWidth, window.innerHeight);
});